# Load necessary library
if (!require(ggplot2)) {
  install.packages("ggplot2")
  library(ggplot2)
}

# Read command line arguments
args <- commandArgs(trailingOnly = TRUE)

# Check for proper usage
if (length(args) != 1) {
  stop("Usage: Rscript script_name.R input_file.tsv")
}

# Get the input file path from the command line
input_file <- args[1]

# Read the tab-separated input file, skipping the header
data <- read.table(input_file, header = TRUE, sep = "\t")

# Extract the second-last (Z scores) and last (p-values) columns
z_values <- data[[ncol(data) - 1]]
p_values <- data[[ncol(data)]]

# Filter out rows where p-value is zero or Z or p-values are NA
valid_indices <- !is.na(z_values) & !is.na(p_values) & p_values != 0
z_values <- z_values[valid_indices]
p_values <- p_values[valid_indices]

text_theme <- theme(
  plot.title = element_text(size = 20, face = "bold"),  # Title size
  axis.title = element_text(size = 30),                # Axis title size
  axis.text = element_text(size = 30)                  # Axis tick label size
)

# Create a histogram for Z values
z_hist <- ggplot(data.frame(z = z_values), aes(x = z)) +
  geom_histogram(binwidth = 1, fill = "blue", color = "black") +
  labs(
       x = "Z Value",
       y = "Frequency") +
  theme_minimal() +
  theme(panel.background = element_rect(fill = "white", color = NA),
        plot.background = element_rect(fill = "white", color = NA),
        axis.text = element_text(color = "black"),
        panel.border = element_blank(),               # Remove the panel border
        plot.margin = unit(c(0, 0, 0, 0), "cm")) +
  text_theme

# Save the Z histogram as a PNG file
ggsave("b_xxx_Z_histogram.png", plot = z_hist, width = 8, height = 6, units = "in")

# Create a histogram for p-values
p_hist <- ggplot(data.frame(p = p_values), aes(x = p)) +
  geom_histogram(binwidth = 0.05, fill = "red", color = "black") +
  labs(
       x = "p-value",
       y = "Frequency") +
  theme_minimal() +
  theme(panel.background = element_rect(fill = "white", color = NA),
        plot.background = element_rect(fill = "white", color = NA),
        axis.text = element_text(color = "black"),
        panel.border = element_blank(),               # Remove the panel border
        plot.margin = unit(c(0, 0, 0, 0), "cm")) +
  text_theme

# Save the p-value histogram as a PNG file
ggsave("c_xxx_p_histogram.png", plot = p_hist, width = 8, height = 6, units = "in")

# Filter p-values to include only those <= 0.1
filtered_p_values <- p_values[p_values <= 0.1]

# Create a histogram for p-values <= 0.1, using log scale for the x-axis
log_x_hist <- ggplot(data.frame(p = filtered_p_values), aes(x = p)) +
  geom_histogram(binwidth = 0.1, fill = "green", color = "black") +
  scale_x_log10() +
  labs(
       x = "p-value",
       y = "Frequency") +
  theme_minimal() +
  theme(panel.background = element_rect(fill = "white", color = NA),
        plot.background = element_rect(fill = "white", color = NA),
        axis.text = element_text(color = "black"),
        panel.border = element_blank(),               # Remove the panel border
        plot.margin = unit(c(0, 0, 0, 0), "cm")) +
  text_theme

# Save the log-scaled p-value histogram as a PNG file
ggsave("d_xxx_filtered_p_histogram.png", plot = log_x_hist, width = 8, height = 6, units = "in")
